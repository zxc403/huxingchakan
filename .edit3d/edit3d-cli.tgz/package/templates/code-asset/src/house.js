import * as THREE from 'three'

export function createHouse() {
  const house = new THREE.Group()
  house.name = 'house'
  const wall = new THREE.Mesh(
    new THREE.BoxGeometry(3, 2.3, 2.7),
    new THREE.MeshStandardMaterial({ color: 0xd8b07d, roughness: 0.8 }),
  )
  wall.name = 'wall'
  wall.position.y = 1.15
  const roof = new THREE.Mesh(
    new THREE.ConeGeometry(2.2, 1.5, 4),
    new THREE.MeshStandardMaterial({ color: 0x8e4435, roughness: 0.9 }),
  )
  roof.name = 'roof'
  roof.position.y = 3.05
  roof.rotation.y = Math.PI / 4
  house.add(wall, roof)
  return house
}
export const House = createHouse()
