export { House, createHouse } from './house.js'
