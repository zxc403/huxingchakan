import * as THREE from 'three'
import { playCube } from './game.js'

// Use async createScene + await asset.loadModel('/models/file.glb') for imported assets.
// The SDK owns model resources; create a fresh model for each scene/Play session.
export function createScene({ asset }) {
  const scene = new THREE.Scene()
  scene.background = new THREE.Color('#b9dbef')
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100)
  camera.position.set(0, 5, 12)
  camera.lookAt(0, 0, 0)
  const light = new THREE.HemisphereLight(0xffffff, 0x547353, 3)
  const cube = new THREE.Mesh(new THREE.BoxGeometry(), new THREE.MeshStandardMaterial({ color: '#f1c65c' }))
  const floor = new THREE.Mesh(new THREE.BoxGeometry(20, 0.2, 8), new THREE.MeshStandardMaterial({ color: '#81ac83' }))
  floor.position.y = -0.6
  scene.add(camera, light, cube, floor)
  for (const [id, object] of Object.entries({ scene, camera, light, cube, floor })) asset.register(id, object)
  const settings = { speed: 4 }
  asset.registerParams('movement', settings, { speed: { type: 'number', label: '移动速度', min: 0, max: 20 } })
  return {
    scene,
    camera,
    play: (context) => playCube(context, cube, settings),
    dispose() {
      const resources = new Set()
      scene.traverse((object) => {
        if (object.geometry) resources.add(object.geometry)
        for (const m of [object.material].flat()) if (m) resources.add(m)
      })
      for (const resource of resources) resource.dispose()
    },
  }
}
