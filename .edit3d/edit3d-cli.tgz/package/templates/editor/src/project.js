import { createScene } from './scene.js'

// Add independent scene factories here. Each receives its own SDK instance.
export function createProject() {
  return {
    id: 'my-project',
    name: '我的项目',
    defaultSceneId: 'main',
    scenes: [{ id: 'main', name: '主场景', createScene }],
  }
}
