import * as THREE from 'three'

// Build and review ordinary Three.js content first; configureEditor binds the approved result.
// Do not use DOM, renderer or requestAnimationFrame here. Async functions are supported.
// Import models with await asset.loadModel('/models/file.glb'), then add/register its object.
// Keep referenced materials/textures in public/; the SDK owns decoders and imported resources.
export function createScene({ asset }) {
  const scene = new THREE.Scene()
  scene.background = new THREE.Color(0x34373d)
  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 200)
  camera.position.set(10, 7, 12)
  camera.lookAt(0, 1, 0)
  scene.add(camera)

  const ambient = new THREE.HemisphereLight(0xddeeff, 0x443c30, 2)
  const sun = new THREE.DirectionalLight(0xffeedb, 3)
  sun.position.set(4, 8, 5)
  sun.castShadow = true
  sun.shadow.mapSize.set(1024, 1024)
  scene.add(ambient, sun)

  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(30, 30),
    new THREE.MeshStandardMaterial({ color: 0x62695e, roughness: 1 }),
  )
  ground.rotation.x = -Math.PI / 2
  ground.receiveShadow = true
  scene.add(ground)

  // Replace this procedural group with an import from your downloaded code asset.
  const house = new THREE.Group()
  const wall = new THREE.Mesh(
    new THREE.BoxGeometry(3, 2.3, 2.7),
    new THREE.MeshStandardMaterial({ color: 0xd8b07d, roughness: 0.8 }),
  )
  wall.position.y = 1.15
  const roof = new THREE.Mesh(
    new THREE.ConeGeometry(2.2, 1.5, 4),
    new THREE.MeshStandardMaterial({ color: 0x8e4435, roughness: 0.9 }),
  )
  roof.position.y = 3.05
  roof.rotation.y = Math.PI / 4
  house.add(wall, roof)
  house.traverse((object) => {
    if (object.isMesh) object.castShadow = true
  })
  scene.add(house)

  ground.material.name = '地面 · 哑光'
  wall.material.name = '墙体 · 暖色'
  roof.material.name = '屋顶 · 陶红'

  const sphere = new THREE.Mesh(
    new THREE.SphereGeometry(0.8, 32, 16),
    new THREE.MeshStandardMaterial({ color: 0x789ca8, roughness: 0.3, metalness: 0.2 }),
  )
  sphere.material.name = '球体 · 蓝灰金属'
  sphere.position.set(3.4, 0.8, 1)
  sphere.castShadow = true
  scene.add(sphere)

  // Keep this adapter small. Implement and inspect the content before adding controls.
  return {
    scene,
    camera,
    configureEditor() {
      asset.register('scene', scene, { name: '场景' })
      asset.register('house_001', house, { name: '房子', type: 'building' })
      asset.register('wall_001', wall, { name: '墙体', parent: 'house_001' })
      asset.register('roof_001', roof, { name: '屋顶', parent: 'house_001' })
      asset.register('sphere_001', sphere, { name: '球体' })
      asset.register('ground', ground, { name: '地面' })
      asset.register('camera_main', camera, { name: '主相机' })
      asset.register('sun', sun, { name: '主光' })
      asset.register('ambient', ambient, { name: '环境光' })
    },
    dispose() {
      scene.traverse((object) => {
        object.geometry?.dispose()
        for (const material of [object.material].flat()) material?.dispose()
      })
    },
  }
}
