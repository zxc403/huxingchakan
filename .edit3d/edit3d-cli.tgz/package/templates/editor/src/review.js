// Inspect actual content screenshots and task-specific behavior before passing this review.
// Content changes invalidate old evidence: return to pending and recheck affected states.
// Evidence identifies real screenshots/check results; it is not an aesthetic score from the SDK.
export const review = {
  status: 'pending',
  checks: [], // { name, status: 'passed' | 'failed' | 'unverified', evidence }
  limitations: [],
}
