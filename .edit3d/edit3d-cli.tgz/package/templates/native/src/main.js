import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import './style.css'

const container = document.getElementById('app')
const scene = new THREE.Scene()
scene.background = new THREE.Color('#111519')
const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000)
camera.position.set(6, 4, 8)
const renderer = new THREE.WebGLRenderer({ antialias: true })
renderer.outputColorSpace = THREE.SRGBColorSpace
container.append(renderer.domElement)
const controls = new OrbitControls(camera, renderer.domElement)
controls.enableDamping = true

// 在这里按作品需求组织模型、材质、灯光、动画、交互和渲染流程。
// 先独立完成并在浏览器验收，再将编辑能力连接到这些现有对象与状态。

function resize() {
  const width = Math.max(1, container.clientWidth)
  const height = Math.max(1, container.clientHeight)
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
  renderer.setSize(width, height, false)
  camera.aspect = width / height
  camera.updateProjectionMatrix()
}

let frameId
function frame() {
  controls.update()
  renderer.render(scene, camera)
  frameId = requestAnimationFrame(frame)
}
resize()
frame()
window.addEventListener('resize', resize)

function dispose() {
  cancelAnimationFrame(frameId)
  window.removeEventListener('resize', resize)
  controls.dispose()
  renderer.dispose()
  renderer.domElement.remove()
}
if (import.meta.hot) import.meta.hot.dispose(dispose)
